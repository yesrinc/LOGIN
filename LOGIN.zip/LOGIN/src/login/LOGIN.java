
package login;

import login.IGU.Principal;

/**
 *
 * @author yese1
 */
public class LOGIN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
       Principal princ = new Principal();
       princ.setVisible(true);
       princ.setLocationRelativeTo(null);
        
        
        
    }
    
}
 