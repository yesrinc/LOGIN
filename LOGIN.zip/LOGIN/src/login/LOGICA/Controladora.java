package login.LOGICA;

import java.util.List;
import login.PERSISTENCIA.ControladoraPersistencia;

/**
 *
 * @author yese1
 */
public class Controladora {
    
    ControladoraPersistencia controlPersis = new ControladoraPersistencia();

    public Controladora() {
        controlPersis = new  ControladoraPersistencia();
    }
    public String validarUsuario(String usuario, String contrasena) {
        String mensaje = " ";
        
        List<Usuario> ListaUsuarios = controlPersis.traerUsuarios();
        
         for (Usuario usu : ListaUsuarios)    { 
             
        if (usu.getNombreUsuario().equals(usu)) { 
             
             
             if (usu.getContrasena().equals(contrasena)) {
                 
                  mensaje = "Usuario y Contraseña correctos.  Bienvenido/a";    
                  return mensaje;  
          }
             else {
           mensaje = "Contraseña Incorrecta";
           return mensaje; 
           
      }
        }
        else {
            mensaje = "Usuario no encontrado"; 
                // return mensaje; 
                }
            }
         
            return mensaje; 
         }
     }