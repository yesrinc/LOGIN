
package login.PERSISTENCIA;

import java.util.List;
import login.LOGICA.Usuario;

/**
 *
 * @author yese1
 */
public class ControladoraPersistencia {
    UsuarioJpaController  usuJpa = new UsuarioJpaController ();

    public List<Usuario> traerUsuarios() {
      return usuJpa.findUsuarioEntities();
      
    }
    
    
}
